-- Materials_IncomingAndConsumptionRecords에 입고 내역이 등록될 때 실행되는 트리거:
DELIMITER //

CREATE TRIGGER after_material_incoming
AFTER INSERT ON Materials_IncomingAndConsumptionRecords
FOR EACH ROW
BEGIN
    -- FinancialRecords에 입고 내역 반영
    INSERT INTO FinancialRecords (recordDate, recordType, transactionCategory, description, amount, transactionStatus, materialRefID)
    VALUES (NEW.incomingDate, '지출', '원자재 구매', CONCAT('원자재 구매 - ', NEW.materialRefID), NEW.cost, '완료', NEW.materialRefID);

    -- RawMaterialsInventory에 입고 수량 반영
    UPDATE RawMaterialsInventory
    SET incomingAmount = incomingAmount + NEW.incomingQuantity
    WHERE materialID = NEW.materialRefID;
END;
//

DELIMITER ;

-- Materials_IncomingAndConsumptionRecords에 소모 내역이 등록될 때 실행되는 트리거:
DELIMITER //

CREATE TRIGGER after_material_consumption
AFTER UPDATE ON Materials_IncomingAndConsumptionRecords
FOR EACH ROW
BEGIN
    IF NEW.consumedQuantity > OLD.consumedQuantity THEN
        -- FinancialRecords에 소모 내역 반영
        INSERT INTO FinancialRecords (recordDate, recordType, transactionCategory, description, amount, transactionStatus, materialRefID)
        VALUES (NEW.consumptionDate, '지출', '원자재 소모', CONCAT('원자재 소모 - ', NEW.materialRefID), (NEW.cost * (NEW.consumedQuantity - OLD.consumedQuantity)), '완료', NEW.materialRefID);
    END IF;
END;
//

DELIMITER ;

-- 의자 생산 또는 재생 시 필요한 원자재 수량 감소 및 기록
DELIMITER //

CREATE TRIGGER after_chair_production_or_regeneration
AFTER INSERT ON ChairInventoryLog
FOR EACH ROW
BEGIN
    DECLARE finished INT DEFAULT 0;
    DECLARE materialID INT;
    DECLARE neededQuantity INT;
    DECLARE pricePerUnit DECIMAL(15, 2);
    DECLARE cur CURSOR FOR
        SELECT materialRefID, quantityRequired, pricePerUnit
        FROM ChairMaterials
        WHERE chairRefID = NEW.chairRefID;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

    IF NEW.transactionType IN ('생산', '재생') THEN
        OPEN cur;

        material_loop: LOOP
            FETCH cur INTO materialID, neededQuantity, pricePerUnit;
            IF finished = 1 THEN
                LEAVE material_loop;
            END IF;

            -- RawMaterialsInventory에서 필요한 원자재 수량 감소
            UPDATE RawMaterialsInventory
            SET consumedAmount = consumedAmount + (neededQuantity * NEW.quantity)
            WHERE materialID = materialID;

            -- Materials_IncomingAndConsumptionRecords에 소모 내역 반영
            INSERT INTO Materials_IncomingAndConsumptionRecords (materialRefID, consumedQuantity, consumptionDate, cost)
            VALUES (materialID, (neededQuantity * NEW.quantity), NOW(), (pricePerUnit * neededQuantity));

            -- FinancialRecords에 금융 기록 추가
            INSERT INTO FinancialRecords (recordDate, recordType, transactionCategory, description, amount, transactionStatus, materialRefID)
            VALUES (NOW(), '지출', '원자재 소모', CONCAT('의자 제조 - ', NEW.chairRefID, ', 원자재 - ', materialID), (pricePerUnit * neededQuantity * NEW.quantity), '완료', materialID);
        END LOOP;

        CLOSE cur;
    END IF;
END;

//
DELIMITER ;



DELIMITER //

-- 새 배송 기록이 추가될 때 실행되는 트리거
CREATE TRIGGER before_delivery_insert
BEFORE INSERT ON DeliveryRecords
FOR EACH ROW
BEGIN
    IF NEW.receivedDate IS NULL THEN
        -- 차량 상태를 '배달중'으로 설정
        UPDATE DeliveryVehicles
        SET status = '배달중'
        WHERE vehicleID = NEW.vehicleRefID;

        -- 직원의 배달 여부를 '배달중'으로 설정
        UPDATE EmployeeManagement
        SET delivery = '배달중'
        WHERE employeeID IN (NEW.driver1RefID, NEW.driver2RefID);
    END IF;
END;
//

-- 기존 배송 기록이 업데이트될 때 실행되는 트리거
CREATE TRIGGER before_delivery_update
BEFORE UPDATE ON DeliveryRecords
FOR EACH ROW
BEGIN
    IF NEW.receivedDate IS NULL THEN
        -- 차량 상태를 '배달중'으로 유지
        UPDATE DeliveryVehicles
        SET status = '배달중'
        WHERE vehicleID = NEW.vehicleRefID;

        -- 직원의 배달 여부를 '배달중'으로 유지
        UPDATE EmployeeManagement
        SET delivery = '배달중'
        WHERE employeeID IN (NEW.driver1RefID, NEW.driver2RefID);
    END IF;
END;
//

DELIMITER ;

DELIMITER //

-- 배송 기록의 receivedDate가 업데이트될 때 실행되는 트리거
CREATE TRIGGER after_delivery_received
AFTER UPDATE ON DeliveryRecords
FOR EACH ROW
BEGIN
    IF NEW.receivedDate IS NOT NULL THEN
        -- 차량 상태를 '운행 가능'으로 업데이트
        UPDATE DeliveryVehicles
        SET status = '운행 가능'
        WHERE vehicleID = NEW.vehicleRefID;

        -- 직원의 배달 여부를 '배달 가능'으로 업데이트
        UPDATE EmployeeManagement
        SET delivery = '배달 가능'
        WHERE employeeID IN (NEW.driver1RefID, NEW.driver2RefID);

        -- ChairInventoryLog에 납품 기록 추가
        INSERT INTO ChairInventoryLog (chairRefID, transactionType, transactionDate, quantity)
        VALUES (NEW.productRefID, '납품', NOW(), NEW.quantity);

        -- ProductInventory의 재고 수량 업데이트
        UPDATE ProductInventory
        SET stockAmount = stockAmount - NEW.quantity
        WHERE productID = NEW.productRefID;

        -- FinancialRecords에 금융 기록 추가
        INSERT INTO FinancialRecords (recordDate, recordType, transactionCategory, description, amount, paymentMethod, transactionStatus, productRefID)
        VALUES (NOW(), '수입', '제품 판매', CONCAT('제품 판매 - ', NEW.productRefID), NEW.saleAmount, '전자 송금', '완료', NEW.productRefID);
    END IF;
END;
//

DELIMITER ;



--차랑 장비 유지보수 트리거

DELIMITER //

CREATE TRIGGER after_truck_maintenance
AFTER INSERT ON Truck_MaintenanceRecords
FOR EACH ROW
BEGIN
    INSERT INTO FinancialRecords (
        recordDate, 
        recordType, 
        transactionCategory, 
        description, 
        amount, 
        paymentMethod, 
        transactionStatus, 
        vehicleRefID
    )
    VALUES (
        NEW.maintenanceDate, 
        '지출', 
        '장비 유지보수', 
        CONCAT('장비 유지보수 - ', NEW.equipmentRefID), 
        NEW.cost, 
        '전자 송금', 
        '완료', 
        NEW.equipmentRefID
    );
END;
//

DELIMITER ;